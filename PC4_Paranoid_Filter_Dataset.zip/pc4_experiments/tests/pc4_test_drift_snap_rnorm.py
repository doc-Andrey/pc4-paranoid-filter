import numpy as np
import matplotlib.pyplot as plt
from filterpy.kalman import KalmanFilter

np.random.seed(42)

# =====================================================
# ЭТАП 2.5 — DRIFT → SNAP BACK + R-NORMALIZED ALPHA
# alpha_target = clamp( (r / r_bar) ** N_POWER, 0..1 )
# где r_bar = EMA(r) (среднее доверие среды)
# =====================================================

T = 2000
t = np.arange(T)

# --- truth ---
truth = 0.3*np.sin(0.005*t) + 0.15*np.sin(0.02*t)

# --- sensors ---
N = 10
noise_std = 0.15
sensors = np.tile(truth, (N, 1))
sensors += np.random.normal(0, noise_std, sensors.shape)

# --- scenario ---
bad_frac = 0.7
n_bad = int(bad_frac * N)

drift_start = 700
snap_step   = 1100
fault_end   = 1200

max_drift = 0.45  # итоговый дрейф к моменту snap_step

for i in range(n_bad):
    drift_len = snap_step - drift_start
    ramp = np.linspace(0, max_drift, drift_len)
    sensors[i, drift_start:snap_step] += ramp

sensors[:n_bad, snap_step:fault_end] += np.random.normal(
    0, 0.08, (n_bad, fault_end - snap_step)
)

# =====================================================
# KALMAN (как раньше)
# =====================================================
kf = KalmanFilter(dim_x=1, dim_z=1)
kf.x = np.array([[0.]])
kf.F = np.array([[1.]])
kf.H = np.array([[1.]])
kf.P *= 1.0
kf.Q = 0.01
kf.R = 1.5

kalman = []
for k in range(T):
    z = np.mean(sensors[:, k])
    kf.predict()
    kf.update(z)
    kalman.append(kf.x[0, 0])
kalman = np.array(kalman)

# =====================================================
# 2-PC4 (mean)
# =====================================================
pc4_2 = np.mean(sensors, axis=0)

# =====================================================
# PARANOID PC4 + PHYSICAL GATE + R-NORMALIZED ALPHA
# =====================================================
K_DOWN = 0.8
K_UP = 0.02

N_POWER = 2              # можно 1..3; ставим 2 как компромисс
MAX_PHYSICAL_DELTA = 0.04

# EMA для r_bar (среднее доверие среды)
# Чем меньше ALPHA_BASE_BETA, тем "длиннее память" (медленнее меняется baseline)
ALPHA_BASE_BETA = 0.01   # ~100 шагов характерная шкала (грубо)

# Ограничение ratio, чтобы не взлетал alpha при случайном всплеске r
RATIO_MIN = 0.50
RATIO_MAX = 1.80

def clamp(x, lo, hi):
    return lo if x < lo else (hi if x > hi else x)

theta = 0.0
gamma = 0.0
a_active = 0.0
last_psi = 0.0

r_bar = None

pc4_p = np.zeros(T)
alpha_hist = np.zeros(T)
r_hist = np.zeros(T)
rbar_hist = np.zeros(T)
ratio_hist = np.zeros(T)

for k in range(T):
    z = np.mean(np.exp(1j * sensors[:, k] * np.pi))
    r = np.abs(z)
    psi_inst = np.angle(z)

    # baseline init
    if r_bar is None:
        r_bar = max(r, 1e-6)

    # update baseline EMA
    r_bar = (1 - ALPHA_BASE_BETA) * r_bar + ALPHA_BASE_BETA * r
    r_bar = max(r_bar, 1e-6)

    # R-normalization
    ratio = r / r_bar
    ratio = clamp(ratio, RATIO_MIN, RATIO_MAX)

    # alpha target from relative trust
    a_target = ratio ** N_POWER
    a_target = clamp(a_target, 0.0, 1.0)

    # physical innovation gate (по углу)
    delta_psi = np.abs(psi_inst - last_psi)
    if delta_psi > MAX_PHYSICAL_DELTA:
        gate_factor = MAX_PHYSICAL_DELTA / delta_psi
        a_target *= gate_factor

    # asymmetric attention dynamics
    if a_target < a_active:
        a_active = (1 - K_DOWN) * a_active + K_DOWN * a_target
    else:
        a_active = (1 - K_UP) * a_active + K_UP * a_target

    # rhythms
    theta = 0.985 * theta + 0.015 * psi_inst
    gamma = 0.6 * gamma + 0.4 * psi_inst

    last_psi = psi_inst

    pc4_p[k] = (theta + a_active * (gamma - theta)) / np.pi
    alpha_hist[k] = a_active
    r_hist[k] = r
    rbar_hist[k] = r_bar
    ratio_hist[k] = ratio

# =====================================================
# METRICS
# =====================================================
def rms(a, b): return np.sqrt(np.mean((a-b)**2))
def maxe(a, b): return np.max(np.abs(a-b))
def jitter(x): return np.mean(np.abs(np.diff(x)))

def report(label, sl):
    print(f"\n=== {label} ===")
    print("RMS   Kalman      :", rms(truth[sl], kalman[sl]))
    print("RMS   2-PC4       :", rms(truth[sl], pc4_2[sl]))
    print("RMS   Paranoid PC4:", rms(truth[sl], pc4_p[sl]))
    print("MAX   Kalman      :", maxe(truth[sl], kalman[sl]))
    print("MAX   2-PC4       :", maxe(truth[sl], pc4_2[sl]))
    print("MAX   Paranoid PC4:", maxe(truth[sl], pc4_p[sl]))
    print("JIT   Kalman      :", jitter(kalman[sl]))
    print("JIT   2-PC4       :", jitter(pc4_2[sl]))
    print("JIT   Paranoid PC4:", jitter(pc4_p[sl]))

print("\n=== SCENARIO: DRIFT → SNAP BACK (2.5 R-NORMALIZED ALPHA) ===")
print(f"bad_frac={bad_frac}, N={N}, drift=[{drift_start}:{snap_step}], snap={snap_step}, end={fault_end}")
print(f"N_POWER={N_POWER}, ALPHA_BASE_BETA={ALPHA_BASE_BETA}, ratio_clip=[{RATIO_MIN},{RATIO_MAX}]")

report("GLOBAL", slice(0, T))
report("PRE [0:700]", slice(0, drift_start))
report("DRIFT [700:1100]", slice(drift_start, snap_step))
report("SNAP [1100:1200]", slice(snap_step, fault_end))
report("POST [1200:2000]", slice(fault_end, T))

# =====================================================
# PLOT
# =====================================================
plt.figure(figsize=(14, 6))
plt.plot(truth, 'k', lw=3, label='Ground truth')
plt.plot(kalman, 'r--', lw=1.1, label='Kalman')
plt.plot(pc4_2, 'royalblue', lw=1.1, label='2-PC4 (mean)')
plt.plot(pc4_p, '#00FF00', lw=2.0, label='R-Norm Paranoid PC4 + physical gate')

plt.axvspan(drift_start, snap_step, color='orange', alpha=0.12, label='DRIFT')
plt.axvspan(snap_step, fault_end, color='red', alpha=0.10, label='SNAP')
plt.axvspan(fault_end, T, color='gray', alpha=0.05, label='POST')

# alpha overlay
plt.plot(alpha_hist * 0.5, color='orange', alpha=0.35, lw=1.0, label='Alpha(att) x0.5')

plt.title("Kalman vs PC4 vs Paranoid PC4 — DRIFT → SNAP BACK (2.5, R-normalized alpha)")
plt.xlabel("Time step")
plt.ylabel("Signal")
plt.legend(loc='upper right')
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()

