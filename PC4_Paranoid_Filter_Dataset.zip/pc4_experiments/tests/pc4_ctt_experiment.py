#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PC4 CTT Experiment (LEMON-inspired) — FULL VERSION

Goal:
Run two training regimes ("low_PC4" vs "high_PC4") and compare:
1) CTT_sigma: input Gaussian noise threshold (classic robustness)
2) CTT_mode_alpha: mode-shift mixing threshold (EC→EO-like transition proxy)

Outputs (default):
~/pc4_runs/
  SUMMARY_PC4_CTT.csv
  MODEL_low_PC4.pt
  MODEL_high_PC4.pt
  CTT_curve_low_PC4.csv
  CTT_curve_high_PC4.csv
  CTT_mode_curve_low_PC4.csv
  CTT_mode_curve_high_PC4.csv
"""

import os
import math
import json
import time
import random
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# =========================
# CONFIG
# =========================

SEED = 42
EPOCHS = 10
BATCH_SIZE = 64
LR = 1e-3

# CTT definitions
CTT_DROP_FRAC = 0.50         # 50% of baseline accuracy
CTT_SIGMA_MAX = 5.0          # scan sigma in [0..CTT_SIGMA_MAX]
CTT_SIGMA_STEPS = 26         # number of sigma points
CTT_ALPHA_STEPS = 21         # number of alpha points for mode-mix scan

# Two training regimes:
# low_PC4 = weaker resilience regularization + no gradient noise
# high_PC4 = stronger resilience regularization + dynamic grad noise (Osipov-like)
REGIMES = {
    "low_PC4": dict(
        fragility_weight=0.00,
        grad_noise_amp=0.00,
        grad_noise_freq=0.00,
        dropout=0.00
    ),
    "high_PC4": dict(
        fragility_weight=0.10,
        grad_noise_amp=0.03,
        grad_noise_freq=10.0,
        dropout=0.20
    )
}

OUT_DIR = os.path.expanduser("~/pc4_runs")
os.makedirs(OUT_DIR, exist_ok=True)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# =========================
# DATA
# =========================

def build_mnist_loaders():
    tfm = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    train_ds = datasets.MNIST("./data", train=True, download=True, transform=tfm)
    test_ds  = datasets.MNIST("./data", train=False, download=True, transform=tfm)
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    test_loader  = DataLoader(test_ds, batch_size=1000, shuffle=False, num_workers=0)
    return train_loader, test_loader


# =========================
# MODEL
# =========================

class SmallNet(nn.Module):
    def __init__(self, dropout=0.0):
        super().__init__()
        self.dropout = nn.Dropout(dropout) if dropout and dropout > 0 else nn.Identity()
        self.fc1 = nn.Linear(784, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 10)
        self.relu = nn.ReLU()

    def forward(self, x, return_hidden=False):
        x = x.view(-1, 784)
        h1 = self.relu(self.fc1(x))
        h1 = self.dropout(h1)
        h2 = self.relu(self.fc2(h1))
        out = self.fc3(h2)
        if return_hidden:
            return out, h2
        return out


# =========================
# MODE SHIFT (EC→EO-like)
# =========================

def mode_shift(x):
    """
    Deterministic, label-agnostic transform to simulate a "state change"
    (EC→EO-like) without touching labels:
    - contrast/brightness shift in normalized space
    - mild spatial high-frequency emphasis (approx edge-like)
    """
    # x: [B,1,28,28]
    # contrast/brightness shift
    y = x * 1.15 + 0.05

    # simple high-pass (edge-ish): y - blurred(y)
    # implement a tiny blur via average pooling
    blur = torch.nn.functional.avg_pool2d(y, kernel_size=3, stride=1, padding=1)
    hp = y - blur
    y = y + 0.35 * hp

    # clamp to reasonable range after normalization
    y = torch.clamp(y, -3.0, 3.0)
    return y


def mix_mode(x, alpha: float):
    """Blend between normal and mode-shifted input"""
    return (1.0 - alpha) * x + alpha * mode_shift(x)


# =========================
# OTL-LIKE GRADIENT NOISE
# =========================

class GradNoise:
    def __init__(self, amp=0.0, freq=0.0):
        self.amp = float(amp)
        self.freq = float(freq)
        self.step = 0

    def noise(self, shape, device):
        if self.amp <= 0:
            return None
        # sinusoidal modulation
        mod = 1.0
        if self.freq > 0:
            mod = 1.0 + math.sin(2 * math.pi * self.freq * (self.step / 1000.0))
        self.step += 1
        return torch.randn(shape, device=device) * (self.amp * mod)


# =========================
# LOSS (fragility penalty)
# =========================

class ResilienceLoss(nn.Module):
    def __init__(self, fragility_weight=0.0):
        super().__init__()
        self.ce = nn.CrossEntropyLoss()
        self.w = float(fragility_weight)

    def forward(self, model, x, y):
        out = model(x)
        ce = self.ce(out, y)
        if self.w <= 0:
            return ce

        # fragility = sensitivity of logits to tiny perturbation
        eps = 0.01
        x2 = x + torch.randn_like(x) * eps
        out2 = model(x2)
        frag = torch.mean((out - out2) ** 2)
        return ce + self.w * frag


# =========================
# EVAL HELPERS
# =========================

@torch.no_grad()
def eval_accuracy(model, loader, sigma=0.0):
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        if sigma and sigma > 0:
            x = x + torch.randn_like(x) * float(sigma)
        out = model(x)
        pred = out.argmax(dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return correct / total


@torch.no_grad()
def eval_accuracy_mode_mix(model, loader, alpha=0.0):
    model.eval()
    correct = 0
    total = 0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        x = mix_mode(x, float(alpha))
        out = model(x)
        pred = out.argmax(dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return correct / total


def measure_ctt_sigma(model, test_loader):
    baseline = eval_accuracy(model, test_loader, sigma=0.0)
    sigmas = np.linspace(0.0, CTT_SIGMA_MAX, CTT_SIGMA_STEPS)
    accs = []
    ctt = float(sigmas[-1])

    for s in sigmas:
        a = eval_accuracy(model, test_loader, sigma=float(s))
        accs.append(a)
        if a < baseline * CTT_DROP_FRAC:
            ctt = float(s)
            break

    return dict(baseline_acc=baseline, ctt_sigma=ctt, sigmas=sigmas, accs=np.array(accs))


def measure_ctt_mode(model, test_loader):
    baseline = eval_accuracy_mode_mix(model, test_loader, alpha=0.0)
    alphas = np.linspace(0.0, 1.0, CTT_ALPHA_STEPS)
    accs = []
    ctt = float(alphas[-1])

    for a in alphas:
        acc = eval_accuracy_mode_mix(model, test_loader, alpha=float(a))
        accs.append(acc)
        if acc < baseline * CTT_DROP_FRAC:
            ctt = float(a)
            break

    return dict(baseline_acc=baseline, ctt_alpha=ctt, alphas=alphas, accs=np.array(accs))


# =========================
# TRAINING
# =========================

def train_regime(regime_name, train_loader, test_loader):
    cfg = REGIMES[regime_name]

    model = SmallNet(dropout=cfg["dropout"]).to(DEVICE)
    opt = optim.Adam(model.parameters(), lr=LR)
    crit = ResilienceLoss(fragility_weight=cfg["fragility_weight"])
    gn = GradNoise(amp=cfg["grad_noise_amp"], freq=cfg["grad_noise_freq"])

    print("\n==============================")
    print(f"TRAINING REGIME: {regime_name}")
    print("==============================")

    model.train()
    for ep in range(1, EPOCHS + 1):
        losses = []
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)

            opt.zero_grad()
            loss = crit(model, x, y)
            loss.backward()

            # gradient noise injection (Osipov-like)
            if cfg["grad_noise_amp"] > 0:
                for p in model.parameters():
                    if p.grad is not None:
                        n = gn.noise(p.grad.shape, device=p.grad.device)
                        if n is not None:
                            p.grad.add_(n)

            opt.step()
            losses.append(loss.item())

        print(f"Epoch {ep}/{EPOCHS} | loss={np.mean(losses):.4f}")

    # save model
    model_path = os.path.join(OUT_DIR, f"MODEL_{regime_name}.pt")
    torch.save(model.state_dict(), model_path)

    # measure CTT_sigma
    ctt_s = measure_ctt_sigma(model, test_loader)
    print(f"CTT_sigma ({regime_name}) = {ctt_s['ctt_sigma']:.3f}")
    print(f"Baseline acc (sigma=0) ({regime_name}) = {ctt_s['baseline_acc']:.4f}")

    # save sigma curve
    curve_s = pd.DataFrame({"sigma": ctt_s["sigmas"][:len(ctt_s["accs"])], "accuracy": ctt_s["accs"]})
    curve_s.to_csv(os.path.join(OUT_DIR, f"CTT_curve_{regime_name}.csv"), index=False)

    # measure CTT_mode
    ctt_m = measure_ctt_mode(model, test_loader)
    print(f"CTT_mode_alpha ({regime_name}) = {ctt_m['ctt_alpha']:.3f}")
    print(f"Baseline acc (alpha=0) ({regime_name}) = {ctt_m['baseline_acc']:.4f}")

    # save mode curve
    curve_m = pd.DataFrame({"alpha": ctt_m["alphas"][:len(ctt_m["accs"])], "accuracy": ctt_m["accs"]})
    curve_m.to_csv(os.path.join(OUT_DIR, f"CTT_mode_curve_{regime_name}.csv"), index=False)

    return dict(
        regime=regime_name,
        ctt_sigma=ctt_s["ctt_sigma"],
        baseline_acc_sigma=ctt_s["baseline_acc"],
        ctt_mode_alpha=ctt_m["ctt_alpha"],
        baseline_acc_mode=ctt_m["baseline_acc"],
        model_path=model_path
    )


def main():
    set_seed(SEED)
    train_loader, test_loader = build_mnist_loaders()

    rows = []
    for reg in ["low_PC4", "high_PC4"]:
        rows.append(train_regime(reg, train_loader, test_loader))

    out = pd.DataFrame(rows)
    out_path = os.path.join(OUT_DIR, "SUMMARY_PC4_CTT.csv")
    out.to_csv(out_path, index=False)

    print("\n=== SUMMARY ===")
    print(out)
    print(f"\nSAVED: {out_path}")
    print(f"SAVED MODELS/CURVES in: {OUT_DIR}")


if __name__ == "__main__":
    main()

