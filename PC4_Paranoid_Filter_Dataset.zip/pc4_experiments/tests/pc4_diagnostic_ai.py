# ============================================================
# PC4 DIAGNOSTIC FOR AI MODEL
# Measures stability under MODE SWITCH (not noise)
# ============================================================

import torch
import torch.nn as nn
import numpy as np
import pandas as pd
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from scipy.stats import spearmanr

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ------------------------------------------------------------
# MODEL (same as experiment)
# ------------------------------------------------------------
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(28 * 28, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 10)
        self.relu = nn.ReLU()

    def forward(self, x, return_hidden=False):
        x = x.view(-1, 28 * 28)
        h1 = self.relu(self.fc1(x))
        h2 = self.relu(self.fc2(h1))
        out = self.fc3(h2)
        if return_hidden:
            return out, h2
        return out

# ------------------------------------------------------------
# LOAD TRAINED MODEL
# ------------------------------------------------------------
model = Net().to(DEVICE)
model.load_state_dict(torch.load("MODEL_TO_TEST.pt", map_location=DEVICE))
model.eval()

# ------------------------------------------------------------
# DATA
# ------------------------------------------------------------
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

ds = datasets.MNIST("./data", train=False, download=True, transform=transform)
loader = DataLoader(ds, batch_size=128, shuffle=False)

# ------------------------------------------------------------
# MODE SWITCH
# ------------------------------------------------------------
def mode_shift(x):
    # structured shift: invert + spatial roll
    x = 1.0 - x
    x = torch.roll(x, shifts=2, dims=3)
    return x

# ------------------------------------------------------------
# METRICS
# ------------------------------------------------------------
h_cosines = []
logit_corrs = []
sensitivities = []

with torch.no_grad():
    for x, y in loader:
        x = x.to(DEVICE)

        # MODE A
        out_A, h_A = model(x, return_hidden=True)

        # MODE B
        xB = mode_shift(x)
        out_B, h_B = model(xB, return_hidden=True)

        # ---- H stability (cosine) ----
        cos = torch.nn.functional.cosine_similarity(h_A, h_B, dim=1)
        h_cosines.extend(cos.cpu().numpy())

        # ---- Logit coherence (Spearman) ----
        for i in range(out_A.shape[0]):
            r, _ = spearmanr(out_A[i].cpu().numpy(),
                             out_B[i].cpu().numpy())
            logit_corrs.append(r)

        # ---- Sensitivity proxy ----
        sens = (out_B - out_A).abs().mean(dim=1)
        sensitivities.extend(sens.cpu().numpy())

# ------------------------------------------------------------
# AGGREGATE
# ------------------------------------------------------------
res = {
    "h_cosine_mean": np.nanmean(h_cosines),
    "logit_spearman_mean": np.nanmean(logit_corrs),
    "sensitivity_mean": np.mean(sensitivities),
}

# PC4 proxy score
res["PC4_AI_score"] = (
    res["h_cosine_mean"]
    + res["logit_spearman_mean"]
    - 0.5 * res["sensitivity_mean"]
)

df = pd.DataFrame([res])
df.to_csv("PC4_DIAGNOSTIC.csv", index=False)

print("\n=== PC4 AI DIAGNOSTIC ===")
for k, v in res.items():
    print(f"{k:25s}: {v:.4f}")

