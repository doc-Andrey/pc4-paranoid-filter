import numpy as np
import matplotlib.pyplot as plt
from filterpy.kalman import KalmanFilter

np.random.seed(42)

# =====================================================
# ЭТАП 2.4 — DRIFT → SNAP BACK
# 1) часть сенсоров медленно уходит (drift) в сторону
# 2) в момент snap_step возвращается в норму резко
# =====================================================

T = 2000
t = np.arange(T)

# --- truth ---
truth = 0.3*np.sin(0.005*t) + 0.15*np.sin(0.02*t)

# --- sensors ---
N = 10
noise_std = 0.15
sensors = np.tile(truth, (N, 1))
sensors += np.random.normal(0, noise_std, sensors.shape)

# --- scenario ---
bad_frac = 0.7
n_bad = int(bad_frac * N)

drift_start = 700
snap_step   = 1100
fault_end   = 1200

max_drift = 0.45  # итоговый дрейф к моменту snap_step

# линейный дрейф для "плохих" сенсоров
for i in range(n_bad):
    drift_len = snap_step - drift_start
    ramp = np.linspace(0, max_drift, drift_len)
    sensors[i, drift_start:snap_step] += ramp

    # SNAP BACK: резкий возврат (убираем дрейф сразу)
    sensors[i, snap_step:fault_end] += 0.0

# немного хаоса в периоде возврата (реализм)
sensors[:n_bad, snap_step:fault_end] += np.random.normal(
    0, 0.08, (n_bad, fault_end - snap_step)
)

# =====================================================
# KALMAN
# =====================================================
kf = KalmanFilter(dim_x=1, dim_z=1)
kf.x = np.array([[0.]])
kf.F = np.array([[1.]])
kf.H = np.array([[1.]])
kf.P *= 1.0
kf.Q = 0.01
kf.R = 1.5

kalman = []
for k in range(T):
    z = np.mean(sensors[:, k])
    kf.predict()
    kf.update(z)
    kalman.append(kf.x[0, 0])
kalman = np.array(kalman)

# =====================================================
# 2-PC4 (simple mean)
# =====================================================
pc4_2 = np.mean(sensors, axis=0)

# =====================================================
# PARANOID PC4 + PHYSICAL INNOVATION GATE
# =====================================================
K_DOWN = 0.8
K_UP = 0.02
N_POWER = 3

MAX_PHYSICAL_DELTA = 0.04  # барьер на изменение консенсуса за шаг

theta = 0.0
gamma = 0.0
a_active = 0.0
last_psi = 0.0

pc4_p = np.zeros(T)
alpha_hist = np.zeros(T)

for k in range(T):
    z = np.mean(np.exp(1j * sensors[:, k] * np.pi))
    r = np.abs(z)
    psi_inst = np.angle(z)

    # alpha attention target
    a_target = r ** N_POWER

    # innovation (physical) gate
    delta_psi = np.abs(psi_inst - last_psi)
    if delta_psi > MAX_PHYSICAL_DELTA:
        gate_factor = MAX_PHYSICAL_DELTA / delta_psi
        a_target *= gate_factor

    # asymmetric dynamics
    if a_target < a_active:
        a_active = (1 - K_DOWN) * a_active + K_DOWN * a_target
    else:
        a_active = (1 - K_UP) * a_active + K_UP * a_target

    theta = 0.985 * theta + 0.015 * psi_inst
    gamma = 0.6 * gamma + 0.4 * psi_inst

    last_psi = psi_inst

    pc4_p[k] = (theta + a_active * (gamma - theta)) / np.pi
    alpha_hist[k] = a_active

# =====================================================
# METRICS
# =====================================================
def rms(a, b): return np.sqrt(np.mean((a-b)**2))
def maxe(a, b): return np.max(np.abs(a-b))
def jitter(x): return np.mean(np.abs(np.diff(x)))

def report(label, sl):
    print(f"\n=== {label} ===")
    print("RMS   Kalman      :", rms(truth[sl], kalman[sl]))
    print("RMS   2-PC4       :", rms(truth[sl], pc4_2[sl]))
    print("RMS   Paranoid PC4:", rms(truth[sl], pc4_p[sl]))
    print("MAX   Kalman      :", maxe(truth[sl], kalman[sl]))
    print("MAX   2-PC4       :", maxe(truth[sl], pc4_2[sl]))
    print("MAX   Paranoid PC4:", maxe(truth[sl], pc4_p[sl]))
    print("JIT   Kalman      :", jitter(kalman[sl]))
    print("JIT   2-PC4       :", jitter(pc4_2[sl]))
    print("JIT   Paranoid PC4:", jitter(pc4_p[sl]))

print("\n=== SCENARIO: DRIFT → SNAP BACK ===")
print(f"bad_frac={bad_frac}, N={N}, drift=[{drift_start}:{snap_step}], snap={snap_step}, end={fault_end}")

report("GLOBAL", slice(0, T))
report("PRE [0:700]", slice(0, drift_start))
report("DRIFT [700:1100]", slice(drift_start, snap_step))
report("SNAP [1100:1200]", slice(snap_step, fault_end))
report("POST [1200:2000]", slice(fault_end, T))

# =====================================================
# PLOT
# =====================================================
plt.figure(figsize=(14, 6))
plt.plot(truth, 'k', lw=3, label='Ground truth')
plt.plot(kalman, 'r--', lw=1.1, label='Kalman')
plt.plot(pc4_2, 'royalblue', lw=1.1, label='2-PC4 (mean)')
plt.plot(pc4_p, '#00FF00', lw=2.0, label='Paranoid PC4 + physical gate')

plt.axvspan(drift_start, snap_step, color='orange', alpha=0.12, label='DRIFT')
plt.axvspan(snap_step, fault_end, color='red', alpha=0.10, label='SNAP')
plt.axvspan(fault_end, T, color='gray', alpha=0.05, label='POST')

# alpha overlay (scaled, optional visual)
plt.plot(alpha_hist * 0.5, color='orange', alpha=0.35, lw=1.0, label='Alpha(att) x0.5')

plt.title("Kalman vs PC4 vs Paranoid PC4 — DRIFT → SNAP BACK (2.4)")
plt.xlabel("Time step")
plt.ylabel("Signal")
plt.legend(loc='upper right')
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()

