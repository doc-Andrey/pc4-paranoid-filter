import numpy as np
import matplotlib.pyplot as plt

# --------- ВСПОМОГАТЕЛЬНОЕ: МЕТРИКИ ---------

def circular_error(a, b):
    """Минимальная разница фаз на окружности."""
    diff = np.abs(a - b)
    return np.minimum(diff, 2 * np.pi - diff)

# --------- ОДНОМОДОВЫЙ PC4 (КАК У ТЕБЯ БЫЛО, НО В ВИДЕ ФУНКЦИИ) ---------

def run_single_mode(steps=600, n_sensors=10, dt=0.05,
                    base_freq=2.0, accel=0.005,
                    noise_std=0.05):
    phases = np.zeros(n_sensors)
    refined_signal = []
    r_coherence = []
    true_history = []

    for t in range(steps):
        # динамика цели
        current_freq = base_freq + accel * t
        phase_step = current_freq * dt
        true_val = (t * (base_freq + accel * 0.5 * t) * dt) % (2 * np.pi)
        true_history.append(true_val)

        # сколько датчиков "живы"
        active_sensors = max(2, n_sensors - (t // 60))

        # базовый сигнал + обычный шум
        drive = phase_step + np.random.normal(0, noise_std, n_sensors)

        # мёртвые датчики: чистый хаос
        if active_sensors < n_sensors:
            drive[active_sensors:] = np.random.uniform(
                -np.pi, np.pi, n_sensors - active_sensors
            )

        # ВСТАВКА ВЫСОКОЧАСТОТНОЙ АТАКИ (HF-резонанс) НА ЧАСТЬ АКТИВНЫХ
        if 200 <= t < 400 and active_sensors > 0:
            jam_idx = np.arange(active_sensors // 2)  # половина живых
            drive[jam_idx] += np.random.normal(0, 0.8, len(jam_idx))  # сильный HF-шум

        # ядро PC4: один уровень мод
        z = np.mean(np.exp(1j * phases))
        r = np.abs(z)
        psi = np.angle(z)

        K_sync = 8.0
        phases += drive + K_sync * r * np.sin(psi - phases) * dt

        refined_signal.append(psi)
        r_coherence.append(r)

    refined_signal = np.array(refined_signal)
    true_history = np.array(true_history)
    errors = circular_error(refined_signal, true_history)

    return {
        "errors": errors,
        "R": np.array(r_coherence),
        "true": true_history,
        "refined": refined_signal,
    }

# --------- МУЛЬТИМОДОВЫЙ PC4 (НИЗКИЕ + ВЫСОКИЕ МОДЫ) ---------

def run_multimode(steps=600, n_sensors=10, dt=0.05,
                  base_freq=2.0, accel=0.005,
                  noise_std=0.05):
    # НИЗКАЯ МОДА: "инерционный корень"
    phases_low = np.zeros(n_sensors)
    # ВЫСОКАЯ МОДА: "быстрая кора"
    phases_high = np.zeros(n_sensors)

    refined_signal = []
    R_low_list = []
    R_high_list = []
    true_history = []

    # параметры связи
    K_low = 10.0     # сильное стягивание низких мод
    K_high = 6.0     # более мягкое стягивание высоких мод
    K_couple = 5.0   # связь high ↔ low (якорение)
    hf_attack_std = 0.8  # амплитуда HF-атаки на датчики

    for t in range(steps):
        # истинная динамика цели
        current_freq = base_freq + accel * t
        phase_step = current_freq * dt
        true_val = (t * (base_freq + accel * 0.5 * t) * dt) % (2 * np.pi)
        true_history.append(true_val)

        # активные датчики
        active_sensors = max(2, n_sensors - (t // 60))

        # базовый сигнал: то, что "должно" происходить
        base_drive = phase_step

        # НИЗКАЯ МОДА: НЕ ВИДИТ ВЫСОКОЧАСТОТНЫЙ ШУМ, ТОЛЬКО ГЛАДКИЙ ДРАЙВ
        drive_low = np.full(n_sensors, base_drive)

        # ВЫСОКАЯ МОДА: ВИДИТ И СИГНАЛ, И ШУМ
        drive_high = base_drive + np.random.normal(0, noise_std, n_sensors)

        # мёртвые датчики для high: чистый хаос
        if active_sensors < n_sensors:
            drive_high[active_sensors:] = np.random.uniform(
                -np.pi, np.pi, n_sensors - active_sensors
            )

        # HF-АТАКА ТОЛЬКО НА ВЫСОКИЕ МОДЫ ЧАСТИ АКТИВНЫХ ДАТЧИКОВ
        if 200 <= t < 400 and active_sensors > 0:
            jam_idx = np.arange(active_sensors // 2)
            drive_high[jam_idx] += np.random.normal(
                0, hf_attack_std, len(jam_idx)
            )

        # --- ОБНОВЛЕНИЕ НИЗКОЙ МОДЫ ---
        z_low = np.mean(np.exp(1j * phases_low))
        R_low = np.abs(z_low)
        psi_low = np.angle(z_low)

        phases_low += drive_low + K_low * R_low * np.sin(psi_low - phases_low) * dt

        # --- ОБНОВЛЕНИЕ ВЫСОКОЙ МОДЫ С ЯКОРЕНИЕМ НА НИЗКУЮ ---
        z_high = np.mean(np.exp(1j * phases_high))
        R_high = np.abs(z_high)
        psi_high = np.angle(z_high)

        # связь с датчиками + внутренняя синхронизация + притяжение к низкой моде
        phases_high += (
            drive_high
            + K_high * R_high * np.sin(psi_high - phases_high) * dt
            + K_couple * np.sin(psi_low - phases_high) * dt
        )

        # ОЦЕНКА ФАЗЫ СИСТЕМЫ ПО ВЫСОКОЙ МОДЕ (НО УЖЕ С ЯКОРЕМ)
        z_out = np.mean(np.exp(1j * phases_high))
        psi_out = np.angle(z_out)

        refined_signal.append(psi_out)
        R_low_list.append(R_low)
        R_high_list.append(R_high)

    refined_signal = np.array(refined_signal)
    true_history = np.array(true_history)
    errors = circular_error(refined_signal, true_history)

    return {
        "errors": errors,
        "R_low": np.array(R_low_list),
        "R_high": np.array(R_high_list),
        "true": true_history,
        "refined": refined_signal,
    }

# --------- ГЛАВНЫЙ ТЕСТ: ОДИНАКОВЫЙ СЦЕНАРИЙ ДЛЯ ОБОИХ ---------

def pc4_multimode_final_boss():
    steps = 600
    n_sensors = 10
    dt = 0.05

    print("=== ЗАПУСК СТЕСС-ТЕСТА ===")
    print(f"Шаги: {steps}, датчиков: {n_sensors}, dt={dt}")

    single = run_single_mode(steps=steps, n_sensors=n_sensors, dt=dt)
    multi = run_multimode(steps=steps, n_sensors=n_sensors, dt=dt)

    e_single = single["errors"]
    e_multi = multi["errors"]
    R_single = single["R"]
    R_low = multi["R_low"]
    R_high = multi["R_high"]

    # Разбиение на три участка: до атаки, во время, после
    idx_pre = np.arange(0, 200)
    idx_attack = np.arange(200, 400)
    idx_post = np.arange(400, 600)

    def seg_stats(e, idx):
        return float(np.mean(e[idx])), float(np.max(e[idx]))

    print("\n=== СРЕДНЯЯ / МАКСИМАЛЬНАЯ ОШИБКА (рад) ===")
    for name, arr in [("Single", e_single), ("Multi", e_multi)]:
        m_pre, M_pre = seg_stats(arr, idx_pre)
        m_att, M_att = seg_stats(arr, idx_attack)
        m_post, M_post = seg_stats(arr, idx_post)
        print(f"\n{name} mode:")
        print(f"  До атаки   : mean={m_pre:.4f}, max={M_pre:.4f}")
        print(f"  Во время   : mean={m_att:.4f}, max={M_att:.4f}")
        print(f"  После атаки: mean={m_post:.4f}, max={M_post:.4f}")

    print("\n=== ФИНАЛЬНАЯ КОГЕРЕНТНОСТЬ R ===")
    print(f"Single R_end : {R_single[-1]:.3f}")
    print(f"Multi  R_low : {R_low[-1]:.3f}")
    print(f"Multi R_high : {R_high[-1]:.3f}")

    # ВИЗУАЛИЗАЦИЯ
    t = np.arange(steps)

    fig, ax1 = plt.subplots(figsize=(12, 6))
    ax1.plot(t, e_single, label="Error Single-mode", linewidth=1.0)
    ax1.plot(t, e_multi, label="Error Multi-mode", linewidth=1.0, linestyle="--")
    ax1.set_xlabel("Step")
    ax1.set_ylabel("Phase error (rad)")

    ax2 = ax1.twinx()
    ax2.plot(t, R_single, label="R Single", alpha=0.3)
    ax2.plot(t, R_low, label="R_low (anchor)", alpha=0.3)
    ax2.plot(t, R_high, label="R_high (fast)", alpha=0.3)
    ax2.set_ylabel("Coherence R")

    plt.title("PC4: Single vs Multi-mode under HF attack + sensor loss")
    fig.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig("pc4_multimode_final_boss.png")
    plt.show()

    print("\nСОХРАНЕНО: pc4_multimode_final_boss.png")


if __name__ == "__main__":
    pc4_multimode_final_boss()

