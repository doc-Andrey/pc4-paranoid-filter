import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

# =========================
# PARAMETERS
# =========================
N = 2000
t = np.arange(N)

FAULT_START = 700
FAULT_END   = 1200
BAD_FRAC    = 0.5
N_SENSORS   = 10

# =========================
# GROUND TRUTH
# =========================
truth = (
    0.25 * np.sin(2*np.pi*t/300) +
    0.18 * np.sin(2*np.pi*t/700)
)

# =========================
# SENSOR MODEL
# =========================
noise = 0.03
sensors = np.zeros((N, N_SENSORS))

for i in range(N_SENSORS):
    sensors[:, i] = truth + np.random.normal(0, noise, N)

# --- ANTIPHASE FAULT ---
bad_idx = np.random.choice(N_SENSORS, int(N_SENSORS*BAD_FRAC), replace=False)
for i in bad_idx:
    sensors[FAULT_START:FAULT_END, i] *= -1

# =========================
# KALMAN (scalar)
# =========================
Q = 1e-4
R = 0.02
x_k = 0.0
P_k = 1.0
kalman = np.zeros(N)

for k in range(N):
    x_pred = x_k
    P_pred = P_k + Q
    z = np.mean(sensors[k])
    K = P_pred / (P_pred + R)
    x_k = x_pred + K * (z - x_pred)
    P_k = (1 - K) * P_pred
    kalman[k] = x_k

# =========================
# 2-PC4
# =========================
pc4_2 = np.mean(sensors, axis=1)

# =========================
# PARANOID PC4 (anti-phase aware)
# =========================
paranoid = np.zeros(N)
x = 0.0
alpha = 0.15

for k in range(N):
    s = sensors[k]
    mean = np.mean(s)
    signs = np.sign(s * mean)
    coherence = np.mean(signs > 0)
    gate = np.clip(coherence, 0.0, 1.0)
    x = x + alpha * gate * (mean - x)
    paranoid[k] = x

# =========================
# METRICS
# =========================
def rms(a, b): return np.sqrt(np.mean((a-b)**2))
def maxe(a, b): return np.max(np.abs(a-b))
def jitter(x): return np.mean(np.abs(np.diff(x)))

def report(label, sl):
    print(f"\n=== {label} ===")
    print(f"RMS   Kalman      : {rms(truth[sl], kalman[sl]):.6f}")
    print(f"RMS   2-PC4       : {rms(truth[sl], pc4_2[sl]):.6f}")
    print(f"RMS   Paranoid PC4: {rms(truth[sl], paranoid[sl]):.6f}")
    print(f"MAX   Kalman      : {maxe(truth[sl], kalman[sl]):.6f}")
    print(f"MAX   2-PC4       : {maxe(truth[sl], pc4_2[sl]):.6f}")
    print(f"MAX   Paranoid PC4: {maxe(truth[sl], paranoid[sl]):.6f}")
    print(f"JIT   Kalman      : {jitter(kalman[sl]):.6f}")
    print(f"JIT   2-PC4       : {jitter(pc4_2[sl]):.6f}")
    print(f"JIT   Paranoid PC4: {jitter(paranoid[sl]):.6f}")

print("\n=== SCENARIO: ANTIPHASE FAULT ===")
print(f"bad_frac={BAD_FRAC}, window=[{FAULT_START}:{FAULT_END}]")

report("GLOBAL", slice(0, N))
report("PRE [0:700]", slice(0, FAULT_START))
report("FAULT [700:1200]", slice(FAULT_START, FAULT_END))
report("POST [1200:2000]", slice(FAULT_END, N))

# =========================
# PLOT
# =========================
plt.figure(figsize=(14,6))
plt.plot(truth, 'k', lw=3, label="Ground truth")
plt.plot(kalman, 'r--', label="Kalman")
plt.plot(pc4_2, 'b', label="2-PC4")
plt.plot(paranoid, 'g', label="Paranoid PC4")
plt.axvspan(FAULT_START, FAULT_END, color='red', alpha=0.1, label="FAULT")
plt.title("Kalman vs PC4 vs Paranoid PC4 — ANTIPHASE Fault (Fixed)")
plt.xlabel("Time step")
plt.ylabel("Signal")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

