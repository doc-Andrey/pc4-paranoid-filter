import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('carla_telemetry.csv')
sensors = df[['sensor_0', 'sensor_1', 'sensor_2', 'sensor_3', 'sensor_4']].values
true_val = df['true_steer'].values

K0, psi_prev = 12.0, 0.0
refined_path = []
phases = sensors * np.pi 

for t in range(len(phases)):
    z = np.mean(np.exp(1j * phases[t]))
    r = np.abs(z)
    # Инерция аттрактора (0.92) - здесь она начнет мешать
    psi = 0.92 * psi_prev + 0.08 * np.angle(z)
    psi_prev = psi
    refined_path.append(psi / np.pi)

plt.figure(figsize=(12, 6))
plt.plot(true_val, 'k--', label='True Course')
plt.plot(df['sensor_0'], 'r', alpha=0.2, label='Vibrating Sensor')
plt.plot(refined_path, 'b', lw=2, label='PC4-Integrity')
plt.legend()
plt.title("STRESS TEST: Phase Lag and Vibration")
plt.savefig('stress_test_result.png')
print(f"Средняя ошибка: {np.mean(np.abs(np.array(refined_path) - true_val)):.4f}")
plt.show()
