import numpy as np
import matplotlib.pyplot as plt

def pc4_modal_resonance():
    steps, n_sensors, dt = 500, 5, 0.05
    target_freq = 2.0
    
    # ПАРАМЕТРЫ РЕЗОНАНСА
    K_sync = 4.0      # Сила стягивания (когерентность)
    Gamma_loss = 0.5  # Коэффициент затухания для "выбивающихся"
    
    phases = np.zeros(n_sensors)
    refined_signal = []
    raw_avg_signal = []
    coherence_r = []

    print("--- Запуск PC4: Модально-Резонансный Анализ ---")

    for t in range(steps):
        # 1. Входной сигнал от датчиков (с шумом и хаосом)
        drive = target_freq * dt + np.random.normal(0, 0.05, n_sensors)
        
        if 150 < t < 350:
            drive[0] += 2.5 * np.sin(t * 0.1) # Аномалия 1
            drive[1] -= 1.5 * np.cos(t * 0.1) # Аномалия 2 (противофаза)

        # 2. МОДАЛЬНЫЙ РЕЗОНАТОР (Ядро теории)
        # Считаем текущий центр резонанса (Комплексный параметр порядка)
        z = np.mean(np.exp(1j * phases))
        r = np.abs(z)
        psi = np.angle(z)

        # Стягивание (Датчики притягиваются к psi, если они в фазе)
        # И гасятся, если они создают диссонанс
        d_phases = drive + K_sync * r * np.sin(psi - phases) * dt
        phases += d_phases

        # Итоговый "очищенный" сигнал — это мода системы
        refined_signal.append(psi)
        raw_avg_signal.append(np.mean(phases) % (2 * np.pi))
        coherence_r.append(r)

    # Визуализация
    true_phases = (np.arange(steps) * target_freq * dt) % (2 * np.pi)
    
    plt.figure(figsize=(12, 6))
    
    # График ошибки
    err_raw = [min(abs(a-b), 2*np.pi-abs(a-b)) for a,b in zip(raw_avg_signal, true_phases)]
    err_pc4 = [min(abs(a-b), 2*np.pi-abs(a-b)) for a,b in zip(refined_signal, true_phases)]
    
    plt.plot(err_raw, color='red', alpha=0.3, label='Сырой сигнал (Без резонанса)')
    plt.plot(err_pc4, color='blue', lw=2, label='PC4 Модальный Резонанс')
    plt.axvspan(150, 350, color='yellow', alpha=0.1, label='Зона фазового хаоса')
    
    plt.title("Модально-резонансная фильтрация PC4")
    plt.ylabel("Отклонение от истинной фазы")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

    gain = np.mean(err_raw[150:350]) / (np.mean(err_pc4[150:350]) + 1e-9)
    print(f"\n[РЕЗУЛЬТАТ] Модальный резонанс удержал точность в {gain:.1f} раз лучше!")

if __name__ == "__main__":
    pc4_modal_resonance()
