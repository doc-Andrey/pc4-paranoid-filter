import numpy as np
import matplotlib.pyplot as plt

def pc4_v3_inertial():
    steps, n_sensors, dt, target_freq = 400, 5, 0.05, 2.0
    phases = np.zeros(n_sensors)
    
    # ПАМЯТЬ СИСТЕМЫ
    predicted_phase = 0.0
    
    r_history, error_standard, error_pc4 = [], [], []

    print("--- Запуск PC4 v3: Инерциальный фильтр активен ---")

    for t in range(steps):
        # 1. Движение и предсказание (экстраполяция)
        predicted_phase = (predicted_phase + target_freq * dt) % (2 * np.pi)
        
        # 2. Реальные фазы с шумом
        phases += target_freq * dt + np.random.normal(0, 0.05, n_sensors)
        
        # Тот же самый жесткий вброс хаоса
        if 150 < t < 300:
            phases[0] += 2.0 * np.sin(t * 0.1) # Агрессивный шум
            phases[1] += 0.15 * (t - 150)     # Резкий дрейф

        # 3. СТАНДАРТНОЕ УСРЕДНЕНИЕ
        std_avg = np.mean(phases) % (2 * np.pi)

        # 4. PC4 V3: Веса на основе близости к ПРЕДСКАЗАНИЮ (Inertia)
        # Мы доверяем датчику, только если он не противоречит физике движения
        weights = []
        for p in phases:
            # Считаем разность фаз между датчиком и предсказанием
            diff = np.cos(p - predicted_phase)
            # Если датчик врет больше чем на 90 градусов - его вес 0
            w = max(0, diff)**8 # Очень жесткий отбор
            weights.append(w)
            
        weights = np.array(weights)
        
        if np.sum(weights) > 0:
            z_final = np.sum(weights * np.exp(1j * phases)) / np.sum(weights)
            current_decision = np.angle(z_final)
        else:
            # Если все датчики врут - верим своей инерции!
            current_decision = predicted_phase

        # Обновляем память системы для следующего шага
        predicted_phase = current_decision 

        true_val = (t * target_freq * dt) % (2 * np.pi)
        error_standard.append(np.abs(std_avg - true_val))
        error_pc4.append(np.abs(current_decision - true_val))

    gain = np.mean(error_standard[150:300]) / (np.mean(error_pc4[150:300]) + 1e-9)
    print(f"\n[РЕЗУЛЬТАТ v3] ТОЧНОСТЬ ВЫРОСЛА В {gain:.1f} РАЗ!")
    
    plt.figure(figsize=(10, 5))
    plt.plot(error_standard, label='Обычный автопилот (Авария)', color='red', alpha=0.3)
    plt.plot(error_pc4, label='PC4 v3 (Инерциальный щит)', color='blue', lw=2)
    plt.yscale('log') # Логарифмическая шкала, чтобы видеть разницу в деталях
    plt.title(f"PC4 v3: Победа над хаосом (Улучшение в {gain:.1f} раз)")
    plt.legend()
    plt.show()

if __name__ == "__main__":
    pc4_v3_inertial()
