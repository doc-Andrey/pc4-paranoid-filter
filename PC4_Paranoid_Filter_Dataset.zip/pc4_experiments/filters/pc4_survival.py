import numpy as np
import matplotlib.pyplot as plt

def pc4_stress_test():
    steps, n_sensors, dt = 500, 5, 0.05
    target_freq = 2.0
    K_sync = 6.0 # Немного усилим стяжку для экстремальных условий
    
    phases = np.zeros(n_sensors)
    refined_signal, raw_avg_signal = [], []

    print("--- СТРЕСС-ТЕСТ PC4: АТАКА 3 ИЗ 5 ---")

    for t in range(steps):
        # Базовый чистый сигнал
        drive = target_freq * dt + np.random.normal(0, 0.03, n_sensors)
        
        # ЖЕСТКАЯ АТАКА (3 датчика сошли с ума синхронно!)
        if 150 < t < 400:
            # Датчики 0, 1 и 2 начинают мощно дрейфовать в сторону
            chaos = 4.0 * np.sin(t * 0.05)
            drive[0] += chaos
            drive[1] += chaos
            drive[2] += chaos 

        # Ядро PC4
        z = np.mean(np.exp(1j * phases))
        r = np.abs(z)
        psi = np.angle(z)

        # Стягивание к моде
        phases += drive + K_sync * r * np.sin(psi - phases) * dt

        refined_signal.append(psi)
        raw_avg_signal.append(np.mean(phases) % (2 * np.pi))

    # Расчет ошибки
    true_phases = (np.arange(steps) * target_freq * dt) % (2 * np.pi)
    def get_err(a, b): return min(abs(a-b), 2*np.pi-abs(a-b))
    
    err_raw = [get_err(a, b) for a,b in zip(raw_avg_signal, true_phases)]
    err_pc4 = [get_err(a, b) for a,b in zip(refined_signal, true_phases)]

    # Визуализация
    plt.figure(figsize=(12, 6))
    plt.plot(err_raw, color='red', alpha=0.3, label='Стандарт (Машина улетела)')
    plt.plot(err_pc4, color='green', lw=2, label='PC4 Shield (Держим удар)')
    plt.fill_between(range(150, 400), 0, 3, color='red', alpha=0.1, label='ЗОНА КРИТИЧЕСКОЙ АТАКИ')
    plt.title(f"Стресс-тест PC4: Атака большинства (3 из 5)")
    plt.legend()
    plt.savefig('pc4_survival_plot.png') # СОХРАНЯЕМ ГРАФИК
    plt.show()

    gain = np.mean(err_raw[150:400]) / (np.mean(err_pc4[150:400]) + 1e-9)
    print(f"\n[РЕЗУЛЬТАТ] Даже при атаке большинства, PC4 выдержал в {gain:.1f} раз лучше!")

if __name__ == "__main__":
    pc4_stress_test()
