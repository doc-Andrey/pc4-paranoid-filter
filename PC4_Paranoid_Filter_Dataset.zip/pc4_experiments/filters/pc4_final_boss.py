import numpy as np
import matplotlib.pyplot as plt

def pc4_ultimate_stress():
    steps, n_sensors, dt = 600, 10, 0.05 # Начнем с 10 датчиков
    base_freq = 2.0
    K_sync = 8.0 
    
    phases = np.zeros(n_sensors)
    refined_signal, true_history = [], []
    r_coherence = []

    print("--- УЛЬТИМАТИВНЫЙ ТЕСТ: Ускорение + Отказ датчиков ---")

    for t in range(steps):
        # 1. Динамическая частота (машина разгоняется)
        current_freq = base_freq + 0.005 * t 
        phase_step = current_freq * dt
        true_val = (t * (base_freq + 0.0025 * t) * dt) % (2 * np.pi)
        true_history.append(true_val)

        # 2. Входной сигнал (с постепенным отключением датчиков)
        # К концу теста останется только 2 живых датчика из 10!
        active_sensors = max(2, n_sensors - (t // 60)) 
        drive = phase_step + np.random.normal(0, 0.05, n_sensors)
        
        # Заполняем "мертвые" датчики чистым хаосом
        if active_sensors < n_sensors:
            drive[active_sensors:] = np.random.uniform(-np.pi, np.pi, n_sensors - active_sensors)

        # 3. Ядро PC4 (Модальный резонанс)
        z = np.mean(np.exp(1j * phases))
        r = np.abs(z)
        psi = np.angle(z)
        
        # Стягивание
        phases += drive + K_sync * r * np.sin(psi - phases) * dt
        
        refined_signal.append(psi)
        r_coherence.append(r)

    # Расчет ошибки
    def get_err(a, b): return min(abs(a-b), 2*np.pi-abs(a-b))
    errors = [get_err(a, b) for a,b in zip(refined_signal, true_history)]

    # Визуализация
    fig, ax1 = plt.subplots(figsize=(12, 6))
    ax1.plot(errors, color='blue', label='Ошибка PC4 (Фазовый дрейф)')
    ax1.set_ylabel('Error (rad)')
    
    ax2 = ax1.twinx()
    ax2.plot(r_coherence, color='green', alpha=0.3, label='Параметр порядка R (Сплоченность)')
    ax2.set_ylabel('Coherence R')
    
    plt.title("Ультимативный тест: Выживание при разгоне и потере 80% датчиков")
    fig.legend(loc="upper right")
    plt.savefig('pc4_final_boss.png')
    plt.show()

    print(f"[ИТОГ] Финальная когерентность R: {r_coherence[-1]:.2f}")
    if r_coherence[-1] > 0.5:
        print("ВЕРДИКТ: СИСТЕМА НЕУБИВАЕМА. РЕЗОНАНС УДЕРЖАН.")
    else:
        print("ВЕРДИКТ: СИСТЕМА РАСПАЛАСЬ.")

if __name__ == "__main__":
    pc4_ultimate_stress()
