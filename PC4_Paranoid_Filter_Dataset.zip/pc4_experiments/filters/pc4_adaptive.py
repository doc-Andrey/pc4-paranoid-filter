import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('carla_telemetry.csv')
sensors = df[['sensor_0', 'sensor_1', 'sensor_2', 'sensor_3', 'sensor_4']].values
true_val = df['true_steer'].values

psi_prev = 0.0
refined_path = []
phases = sensors * np.pi 

for t in range(len(phases)):
    z = np.mean(np.exp(1j * phases[t]))
    r = np.abs(z)
    
    # СУПЕР-АДАПТАЦИЯ (Нелинейная):
    # Мы возводим r в степень, чтобы при малейшем шуме инерция исчезала мгновенно
    alpha_t = 0.98 * (r**4) 
    
    # Динамический шаг коррекции
    psi = alpha_t * psi_prev + (1 - alpha_t) * np.angle(z)
    psi_prev = psi
    refined_path.append(psi / np.pi)

error = np.mean(np.abs(np.array(refined_path) - true_val))

plt.figure(figsize=(12, 6))
plt.plot(true_val, 'k--', label='True Course', alpha=0.5)
plt.plot(refined_path, 'm', lw=2, label=f'Super-Adaptive PC4 (Err: {error:.4f})')
plt.title("FINAL STRESS TEST: Super-Adaptive Logic")
plt.legend()
plt.savefig('final_success.png')
print(f"ИТОГОВАЯ ОШИБКА: {error:.4f}")
plt.show()
