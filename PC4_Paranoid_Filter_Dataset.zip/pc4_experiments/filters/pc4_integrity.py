import numpy as np
import matplotlib.pyplot as plt

def pc4_architectural_integrity():
    steps, n_sensors, dt = 600, 10, 0.05
    base_freq = 2.0
    K0 = 10.0 # Базовая сила связи
    
    phases = np.zeros(n_sensors)
    psi_prev = 0.0 # Память аттрактора
    
    refined_signal, true_history = [], []
    r_coherence, k_effective = [], []

    print("--- ТЕСТ: АРХИТЕКТУРНАЯ ИНЕРЦИЯ И АДАПТИВНАЯ СВЯЗЬ ---")

    for t in range(steps):
        current_freq = base_freq + 0.005 * t 
        phase_step = current_freq * dt
        true_val = (t * (base_freq + 0.0025 * t) * dt) % (2 * np.pi)
        true_history.append(true_val)

        # 1. Жесткий отказ: к концу остается 2 из 10
        active_sensors = max(2, n_sensors - (t // 60)) 
        drive = phase_step + np.random.normal(0, 0.05, n_sensors)
        if active_sensors < n_sensors:
            drive[active_sensors:] = np.random.uniform(-10, 10, n_sensors - active_sensors)

        # 2. Параметр порядка
        z = np.mean(np.exp(1j * phases))
        r = np.abs(z)
        
        # --- ТВОИ ПРАВКИ ---
        # Инерция аттрактора (psi теперь "тяжелый")
        psi = 0.95 * psi_prev + 0.05 * np.angle(z)
        psi_prev = psi
        
        # Адаптивное K (связь пропорциональна согласию)
        k_eff = K0 * r
        # ------------------

        # 3. Динамика PC4
        phases += drive + k_eff * np.sin(psi - phases) * dt
        
        refined_signal.append(psi)
        r_coherence.append(r)
        k_effective.append(k_eff)

    # Ошибка
    def get_err(a, b): return min(abs(a-b), 2*np.pi-abs(a-b))
    errors = [get_err(a, b) for a,b in zip(refined_signal, true_history)]

    # Графики
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    ax1.plot(errors, color='blue', label='Ошибка (с инерцией аттрактора)')
    ax1.set_title("Точность системы при адаптивном резонансе")
    ax1.legend()
    
    ax2.plot(r_coherence, label='Coherence R', color='green')
    ax2.plot(np.array(k_effective)/K0, label='Relative K_eff', ls='--')
    ax2.set_title("Параметры внутренней стабильности")
    ax2.legend()
    
    plt.savefig('pc4_integrity_result.png')
    plt.show()

    print(f"[ИТОГ] Финальная когерентность R: {r_coherence[-1]:.2f}")
    print(f"[ИТОГ] Средняя ошибка в конце: {np.mean(errors[-50:]):.4f} рад")

if __name__ == "__main__":
    pc4_architectural_integrity()
