import numpy as np
import matplotlib.pyplot as plt

def run_pc4_pretrained_model():
    steps, n_sensors, dt = 400, 5, 0.05
    target_freq = 2.0
    
    # "ОБУЧЕННАЯ МАТРИЦА" (Сила связи между датчиками)
    # В PC4 тренировка создает сильную внутреннюю связь (K)
    K_trained = 2.5 
    
    phases = np.zeros(n_sensors)
    history_standard = [] # Без обучения (слабые связи)
    history_pc4 = []      # С импринтингом PC4 (сильные связи)

    # Состояние двух идентичных систем
    p_std = np.zeros(n_sensors)
    p_pc4 = np.zeros(n_sensors)

    print("--- Тест PC4: Архитектурный Импринтинг vs Обычная сеть ---")

    for t in range(steps):
        # Внешний сигнал (правда)
        drive = target_freq * dt + np.random.normal(0, 0.02, n_sensors)
        
        # ВБРОС ХАОСА (Шаг 150-300): Пытаемся "сломать" импринтинг
        if 150 < t < 300:
            drive[0] += 2.0 * np.sin(t * 0.1) # Сбиваем один датчик

        # 1. МОДЕЛЬ БЕЗ PC4 (Слабая архитектура)
        # Она просто следует за входным сигналом
        p_std += drive 
        
        # 2. МОДЕЛЬ С PC4 (Предварительно обученная на резонанс)
        # Датчики связаны между собой силой K (результат тренировки)
        # Это уравнение Курамото, где K - это "обученность" структуры
        avg_phase = np.angle(np.mean(np.exp(1j * p_pc4)))
        coupling = K_trained * np.sin(avg_phase - p_pc4) * dt
        p_pc4 += drive + coupling

        # Считаем ошибку системы (насколько она отклонилась от курса)
        true_val = (t * target_freq * dt) % (2 * np.pi)
        
        err_std = np.abs((np.mean(p_std) % (2 * np.pi)) - true_val)
        err_pc4 = np.abs((np.mean(p_pc4) % (2 * np.pi)) - true_val)
        
        history_standard.append(min(err_std, 2*np.pi - err_std))
        history_pc4.append(min(err_pc4, 2*np.pi - err_pc4))

    # Визуализация
    plt.figure(figsize=(10, 6))
    plt.plot(history_standard, label='Обычная архитектура (Развал)', color='red', alpha=0.5)
    plt.plot(history_pc4, label='PC4-Импринтинг (Удержание структуры)', color='blue', lw=2)
    plt.axvspan(150, 300, color='gray', alpha=0.2, label='Попытка взлома системы')
    plt.title("Результат предварительной тренировки PC4\nСистема сопротивляется искажению за счет внутренних связей")
    plt.ylabel("Отклонение от истины (Ошибка)")
    plt.legend()
    plt.grid(True, alpha=0.2)
    plt.show()

    gain = np.mean(history_standard[150:300]) / np.mean(history_pc4[150:300])
    print(f"\n[ИТОГ] Обученная PC4-структура в {gain:.1f} раз устойчивее к взлому!")

if __name__ == "__main__":
    run_pc4_pretrained_model()
